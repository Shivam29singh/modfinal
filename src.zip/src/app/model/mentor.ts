export class Mentor {
    mentorId : number;
    email :  String;
    password :  String;
	firstName :  String;
    lastName :  String;
    contactNo :  String;
    technology :  String;
	linkedUrl :  String;
    timingSlot :  String;
    mentorStatus :  String;
    experience : String;
}