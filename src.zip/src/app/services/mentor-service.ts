import { Injectable} from '@angular/core';
import { HttpClient, HttpHeaders  } from '@angular/common/http';
import { Mentor } from '../model/mentor';

import { map } from 'rxjs/operators';





const httpOptions = {
    headers : new HttpHeaders({ 'content-type' : 'application/json'})
       }

       
@Injectable({
    providedIn: 'root'
  })
export class MentorService {
       
        constructor(private http : HttpClient){
      
        }

        updateMentor(mentor : Mentor) {
          console.log(mentor);
          return this.http.post('/server/mentor/updateMentor', mentor);
      }
        
        getMentorHistory(mentorId : number) {
       
          return this.http.get('/server/mentor/viewHistory/' + mentorId );
      }

      mentorRegister(mentor : Mentor) {
        return  this.http.post('/server/mentor/mentorRegister', mentor);
       
      }

      getMentorLoginCredentials(email : String , password : String) {
       // console.log(this.http.get('server/mentor/mentorLoginCheck'));
        return this.http.get<any>('server/mentor/mentorLoginChec/' +  email+ '/' + password ).pipe(map((user: { token: any; }) => {
          // login successful if there's a jwt token in the response
          if (user && user.token) {
              // store user details and jwt token in local storage to keep user logged in between page refreshes
              localStorage.setItem('currentUser', JSON.stringify(user));
          }

          return user;
      }));
     
      }
    }