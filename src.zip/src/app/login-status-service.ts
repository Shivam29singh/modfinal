import { Injectable} from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class LoginStatusService {



  constructor() { }
  userLoginStatus:boolean;
  adminLoginStatus:boolean
  mentorLoginStatus:boolean
  routingStatus:boolean;

  setUserLoginStatus(loginStatus:boolean){
this.userLoginStatus = loginStatus;
  }

  getUserLoginStatus() :boolean {
    return this.userLoginStatus;
  }

  setAdminLoginStatus(loginStatus:boolean){
    this.adminLoginStatus = loginStatus;
      }
    
      getAdminLoginStatus() :boolean {
        return this.adminLoginStatus;
      }
      setMentorLoginStatus(loginStatus:boolean){
        this.mentorLoginStatus = loginStatus;
          }
        
          getMentorLoginStatus() :boolean {
            return this.mentorLoginStatus;
          }
  setRoutingStatus( routingStatus : boolean){
 this. routingStatus =  routingStatus;
  }

  getRoutingStatus() :boolean {
    return this.routingStatus;
  }
}
