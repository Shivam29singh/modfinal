import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'admin-menu',
    templateUrl: './admin-menu.component.html'
})
export class AdminMenuComponent implements OnInit{
    ngOnInit(): void {
      
    }
  
}